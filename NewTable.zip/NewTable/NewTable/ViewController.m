//
//  ViewController.m
//  NewTable
//
//  Created by Jack Lapin on 25.04.15.
//  Copyright (c) 2015 Jack Lapin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

{

}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.news = [NSArray arrayWithObjects:
                 @"Подсчет высоты ячейки",
                 @"Как обновить свой iPhone 4 до 4S",
                 @"Отключаем функцию восстановления в `Просмотре` в Mac OS X Lion Отключаем функцию восстановления в `Просмотре` в Mac OS X Lion Отключаем функцию восстановления в `Просмотре` в Mac OS X Lion Отключаем функцию восстановления в `Просмотре` в Mac OS X Lion ",
                 @"За первые 24 часа Apple получила более миллиона предзаказов на iPhone 4S",
                 @"Fruit Ninja: Puss in Boots появится в App Store уже в этом месяце",
                 @"Sony Pictures хочет снять фильм про Стива Джобса", nil];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"cell";
    
    //Поиск ячейки
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    //Если ячейка не найдена
    if (cell == nil) {
        //Создание ячейки
        cell = [[MyTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                           reuseIdentifier:cellIdentifier];
    }
    
    cell.headerOfNew.text = [_news objectAtIndex:indexPath.row];
    NSLog(@"%@", [_news objectAtIndex:indexPath.row]);
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    CGRect  frame;
    NSDictionary * dic = @{NSFontAttributeName:[UIFont systemFontOfSize:15]};
    float sv = [UIDevice currentDevice].systemVersion.floatValue;
    NSString * text = [_news objectAtIndex:indexPath.row];
//    NSLog(@"%@", text);
    if (sv >= 7.f) {
        frame = [text boundingRectWithSize:CGSizeMake(290, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil];
    }
    float height = 44 + frame.size.height;
    return height;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"News";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _news.count;
}

@end
