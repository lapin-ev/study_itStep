//
//  main.m
//  GetAllProperty
//
//  Created by Genrih Korenujenko on 03.08.15.
//  Copyright (c) 2015 Genrih Korenujenko. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
