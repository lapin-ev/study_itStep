//
//  VCWithRandomItems.h
//  Students
//
//  Created by Jack Lapin on 24.03.15.
//  Copyright (c) 2015 Jack Lapin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VCWithRandomItems : UIViewController
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *Button1LC;

@end
