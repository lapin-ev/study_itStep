//
//  InstaFeedObserver.m
//  TinyInstaFeedObserver
//
//  Created by Jack Lapin on 01.10.15.
//  Copyright © 2015 Jack Lapin. All rights reserved.
//

#import "FOModel.h"

@implementation FOModel

// Insert code here to add functionality to your managed object subclass

@end
