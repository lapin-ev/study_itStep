//
//  AppDelegate.h
//  TinyInstaFeedObserver
//
//  Created by Jack Lapin on 01.10.15.
//  Copyright © 2015 Jack Lapin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

