//
//  LEDataManager.m
//  TinyInstaFeedObserver
//
//  Created by Jack Lapin on 08.10.15.
//  Copyright © 2015 Jack Lapin. All rights reserved.
//

#import "LEDataManager.h"

@implementation LEDataManager

@end
