//
//  FavorController.m
//  WebBrouserProject
//
//  Created by san on 20.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import "FavorController.h"
#import "FavoriteData.h"
#import "FavoriteDataCell.h"

@interface FavorController ()<UITableViewDataSource, UITableViewDelegate>{
    //добавляем связь со сторибордом
    IBOutlet UITableView *table;
}

@end

@implementation FavorController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// переход на главное окно
- (IBAction)return:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

// выполняем действия после выделения ячейки
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    siteObject * site = [[FavoriteData sharedInstance].favorites objectAtIndex:indexPath.row];
    site.isSelected = !site.isSelected;
    
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
     
    //отправляем ссылку для перехода в браузере
   // [[NSNotificationCenter defaultCenter] postNotificationName:@"GoNotification" object:cell.favURL.text];
    
    // переход на главное окно
   // [self dismissViewControllerAnimated:YES completion:nil];
}

// получаем количество строк в секции
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[FavoriteData sharedInstance].favorites count] ;
}

// получаем ячейку
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"favoritecell";
    FavoriteDataCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[FavoriteDataCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    siteObject *ob = [FavoriteData sharedInstance].favorites[indexPath.row];
    
    cell.favHeader.text = ob.header;
    cell.favURL.text = ob.URL;
    
    if (ob.isSelected) {
        [cell.isCheckView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"zelenaja_galochka.jpg"]]];
    } else {
        [cell.isCheckView setBackgroundColor:[UIColor whiteColor]];

    }
    
    return cell;
}

//чистим все избранные
- (IBAction)clearFavorites:(id)sender {
    //удаляем с синголтона все
    [[FavoriteData sharedInstance] removeAllFavorites];
    //перезагружаем таблицу
    [table reloadData];
}

// задаем редактирование ячейки
- (void) tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //удаляем с синголтона
        [[FavoriteData sharedInstance] removeFavoriteLink:indexPath.row];
        //добавляем анимацию для удаления ячейки
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

@end
