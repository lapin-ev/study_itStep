//
//  StoreData.h
//  WebBrouserProject
//
//  Created by san on 19.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StoreData : NSObject

+ (instancetype)sharedInstance;
+ (instancetype)allocWithZone:(struct _NSZone *)zone NS_UNAVAILABLE;
+ (instancetype)alloc NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end
