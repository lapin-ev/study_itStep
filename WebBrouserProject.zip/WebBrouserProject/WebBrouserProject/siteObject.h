//
//  siteObject.h
//  WebBrouserProject
//
//  Created by Jack Lapin on 20.06.15.
//  Copyright © 2015 san. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface siteObject : NSObject

 @property NSString* header;
 @property NSString* URL;
 @property BOOL isSelected;

@end
