//
//  siteObject.m
//  WebBrouserProject
//
//  Created by Jack Lapin on 20.06.15.
//  Copyright © 2015 san. All rights reserved.
//

#import "siteObject.h"

@implementation siteObject

-(void) encodeWithCoder:(NSCoder *)coder {
    
    [coder encodeObject:self.header forKey:@"header"];
    [coder encodeObject:self.URL forKey:@"url"];
    [coder encodeBool:self.isSelected forKey:@"isSelected"];
}

- (id) initWithCoder : (NSCoder *)decoder {
    self = [super init];
    if (self != nil)
    {
        self.header = [decoder decodeObjectForKey:@"header"] ;
        self.URL = [decoder decodeObjectForKey:@"url"];
        self.isSelected = [decoder decodeBoolForKey:@"isSelected"];
    }
    return self;

}

@end
