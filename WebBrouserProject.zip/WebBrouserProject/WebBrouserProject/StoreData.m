//
//  StoreData.m
//  WebBrouserProject
//
//  Created by san on 19.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import "StoreData.h"

@interface StoreData ()
  @property (strong, nonatomic)  NSMutableArray *history;
  @property (strong, nonatomic)  NSMutableArray *favorites;

@end

@implementation StoreData

static StoreData *_manager = nil;

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [super new];
        
    });
    return _manager;
}



@end
