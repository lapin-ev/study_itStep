//
//  FavoriteData.m
//  WebBrouserProject
//
//  Created by san on 20.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import "FavoriteData.h"
#import "siteObject.h"

//ключ для получения и сохранения данных в настройках
#define KEY_FAVOR @"favor"

NSMutableArray * arr;

@implementation FavoriteData



//ссылка на обьект синголтона
static FavoriteData *instance = nil;

//статический метод для получения синголтона
+(FavoriteData *) sharedInstance{
    if(!instance){
        instance = [FavoriteData new];
        //получаем данные с пользовательских настроек
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        //получаем данные с избранных
        NSData *data = [userDefaults objectForKey:KEY_FAVOR];
        instance.favorites = [[NSKeyedUnarchiver unarchiveObjectWithData:data] mutableCopy];
              if(!instance.favorites){
            instance.favorites = [NSMutableArray new];
        }
    }
    arr = [NSMutableArray new];
    return instance;
}


//метод для добавления ссылок в избранное
-(void) addFavoriteLink:(siteObject *)favorLink{
    
    [self.favorites addObject:favorLink];

    //сохраняем изменения
    [self saveFavorProperty];
}

// удаление с избранных
-(void) removeFavoriteLink:(NSInteger)removeLinkIndex{
    [self.favorites removeObjectAtIndex:removeLinkIndex];
    //сохраняем изменения
    [self saveFavorProperty];
}

//сохраняем изменения в избранных
-(void) saveFavorProperty{
    //получаем данные с пользовательских настроек
    NSUserDefaults *userdefaults = [NSUserDefaults standardUserDefaults];
    //сохраняем в настройках
    
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:self.favorites];
    [userdefaults setObject:data forKey:KEY_FAVOR];
    [userdefaults synchronize];

}

// удаление всех избранных
-(void) removeAllFavorites{
    [self.favorites removeAllObjects];
    //сохраняем изменения
    [self saveFavorProperty];
}


@end
