//
//  ViewController.m
//  WebBrouserProject
//
//  Created by san on 17.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import "ViewController.h"
#import "HistoryController.h"
#import "FavoriteData.h"
#import "FavorController.h"
#import "siteObject.h"

#define PREFIX @"http://"

//добавляем делегаты
@interface ViewController () <UIWebViewDelegate, UITextFieldDelegate, UIActionSheetDelegate>{
    //связиваем вебформу со сторибордом
    IBOutlet UIWebView *web;
    //связиваем техтовое поле
    IBOutlet UITextField *url;
    //добавляем массим для хранение ссылок с историей
    NSMutableArray *historyData;
    //добавляем массим для хранение ссылок с избранными
    NSMutableArray *favoriteData;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //инициализируем историю и избранные
    historyData = [NSMutableArray new];
    favoriteData = [NSMutableArray new];
    
    //создаем ссылку
    NSURL *link = [NSURL URLWithString:@"http://www.imaladec.com"];
    //переходим в браузере по ссылке
    [web loadRequest:[NSURLRequest requestWithURL:link]];
    //отправляем ссылку для записи в историю
    [historyData addObject: @"http://www.imaladec.com"];
    
    //добавляем обработчик локальных сообщения для перехода по ссылкам с других форм
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(goNotification:)
                                                 name:@"GoNotification"
                                               object:nil];
}

// переходим по полученной ссылке
- (void)goNotification:(NSNotification*)notification {
    NSURL *link = [NSURL URLWithString:[notification object]];
    //переходим в браузере по ссылке
    [web loadRequest:[NSURLRequest requestWithURL:link]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// обновляем строку после обновления страницы (не забываем свзяать делегат)
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    // уставливаем текущую ссылку в строке ввода
    if (![url.text isEqualToString: webView.request.URL.absoluteString]) {
        url.text = webView.request.URL.absoluteString;
        //отправляем ссылку для записи в историю
        [historyData addObject: url.text];
    }
}

// переход по ссылке
// stop reload back next сваязываем напрямую через UIWebView
- (IBAction)go:(id)sender {
    NSURL *link = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", PREFIX, url.text]];
    //переходим в браузере по ссылке
    [web loadRequest:[NSURLRequest requestWithURL:link]];
    [self updateLink];
}

-(void)updateLink{
    //проверяем есть ли www в начале ссылки
    BOOL prefix = [url.text hasPrefix:@"http"];
    if(!prefix)
    {
        //если нет добавляем
        url.text = [NSString stringWithFormat:@"%@%@", @"http://", url.text];
    }
    //отправляем ссылку для записи в историю
    [historyData addObject: url.text];
}

//прячем клавиатуру по нажатию return (не забываем свзяать делегат)
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

//создаем меню добавляя делегат к нашему контроллеру
- (IBAction)history:(id)sender {
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@""
                                 message:@"Select you Choice"
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* history = [UIAlertAction
                         actionWithTitle:@"History"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [self goToStoryList];
                             [view dismissViewControllerAnimated:YES completion:nil];
                             
                         }];
    UIAlertAction* favorites = [UIAlertAction
                             actionWithTitle:@"Faforites"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [self goToFavoriteList];
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    
    [view addAction:history];
    [view addAction:favorites];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
}

//выполняем действия по нажатию кнопки в UIActionSheet


- (void) goToStoryList {
    // переходим на контроллер с историей (нужен импорт класса с контроллером)
    HistoryController *vc2 =[self.storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([HistoryController class])];
    vc2.historyData = historyData;
    [self presentViewController: vc2 animated:YES completion:nil];
    
}

- (void) goToFavoriteList {
    // переходим на контроллер с избранным (нужен импорт класса с контроллером)
    FavorController *vc3 =[self.storyboard instantiateViewControllerWithIdentifier:NSStringFromClass([FavorController class])];
    [self presentViewController: vc3 animated:YES completion:nil];
    
}
//добавляем в синголтон ссылку на избранное
- (IBAction)addFavoriteUrl:(id)sender {
    siteObject * fav = [siteObject new];
    
    fav.header = [web stringByEvaluatingJavaScriptFromString:@"document.title"];
    fav.URL = url.text;
    fav.isSelected = NO;
    
    [[FavoriteData sharedInstance] addFavoriteLink:fav];
}

@end
