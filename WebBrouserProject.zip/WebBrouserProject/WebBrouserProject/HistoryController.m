//
//  HistoryController.m
//  WebBrouserProject
//
//  Created by san on 19.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import "HistoryController.h"


@interface HistoryController ()<UITableViewDataSource, UITableViewDelegate>{
    //добавляем связь со сторибордом
    IBOutlet UITableView *table;
}

@end

@implementation HistoryController

@synthesize historyData;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// переход на главное окно
- (IBAction)return:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];

}

//чистим всю историю
- (IBAction)clearHistory:(id)sender {
    
}

// выполняем действия после выделения ячейки
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITableViewCell *cell = [table cellForRowAtIndexPath:indexPath];

    //отправляем ссылку для перехода в браузере
    [[NSNotificationCenter defaultCenter] postNotificationName:@"GoNotification" object:cell.textLabel.text  userInfo:@{@"time":@"currenttime"}];
    
    // переход на главное окно
        [self dismissViewControllerAnimated:YES completion:nil];
}

// получаем количество строк в секции
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return historyData.count;
}

// получаем ячейку
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = historyData[indexPath.row];
    return cell;
}

// задаем редактирование ячейки
- (void) tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //удаляем с синголтона
        [historyData removeObjectAtIndex: indexPath.row];
        //добавляем анимацию для удаления ячейки
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

@end
