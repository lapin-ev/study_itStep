//
//  FavoriteDataCell.m
//  WebBrouserProject
//
//  Created by Jack Lapin on 20.06.15.
//  Copyright © 2015 san. All rights reserved.
//

#import "FavoriteDataCell.h"

@implementation FavoriteDataCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
