//
//  HistoryController.h
//  WebBrouserProject
//
//  Created by san on 19.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryController : UIViewController

//добавляем массим для хранение ссылок с историей
@property (strong, nonatomic) NSMutableArray *historyData;

@end
