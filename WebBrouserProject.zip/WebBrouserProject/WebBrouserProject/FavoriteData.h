//
//  FavoriteData.h
//  WebBrouserProject
//
//  Created by san on 20.06.15.
//  Copyright (c) 2015 san. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "siteObject.h"

@interface FavoriteData : NSObject

//массив с избранными
@property (nonatomic) NSMutableArray *favorites;

//получить ссылку на синголтон
+(FavoriteData *) sharedInstance;

//метод для добавления ссылок в избранное
-(void) addFavoriteLink:(siteObject *)favorLink;

// удаление с избранных
-(void) removeFavoriteLink:(NSInteger)removeLinkIndex;

// удаление всех избранных
-(void) removeAllFavorites;



@end
