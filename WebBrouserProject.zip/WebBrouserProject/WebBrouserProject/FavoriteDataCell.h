//
//  FavoriteDataCell.h
//  WebBrouserProject
//
//  Created by Jack Lapin on 20.06.15.
//  Copyright © 2015 san. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoriteDataCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *favHeader;
@property (weak, nonatomic) IBOutlet UILabel *favURL;
@property BOOL isCheck;
@property (weak, nonatomic) IBOutlet UIView *isCheckView;

@end
