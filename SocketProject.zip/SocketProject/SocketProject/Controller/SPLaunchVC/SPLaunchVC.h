//
//  SPLaunchVC.h
//  SocketProject
//
//  Created by Genrih Korenujenko on 07.10.15.
//  Copyright © 2015 Genrih Korenujenko. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPLaunchVC : UIViewController

@end
