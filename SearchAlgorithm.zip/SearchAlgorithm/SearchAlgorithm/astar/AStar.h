//
// Created by Jack Lapin on 12.02.15.
// Copyright (c) 2015 JackLapin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AStar.h"
#import "ASnode.h"


@interface AStar : NSObject


/*
/* methods
 */

- (void)createGrid:(int)x :(int)y;

- (void)print;

- (ASnode *)findPath:(ASnode *)nodeA :(ASnode *)nodeB;

- (void ) setObstacle : (ASnode *) node;


@end