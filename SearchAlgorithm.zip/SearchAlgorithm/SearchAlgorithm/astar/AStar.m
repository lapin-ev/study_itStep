//
// Created by Jack Lapin on 12.02.15.
// Copyright (c) 2015 JackLapin. All rights reserved.
//


#import "AStar.h"

@implementation AStar
{
    ASnode *_startPoint;
    ASnode *_finishPoint;
    ASnode *_maxPoint;
    NSArray *_grid;
    NSMutableArray *_obstacles;


}

- (void)createGrid:(int)x :(int)y
{

    NSMutableArray *rows = [NSMutableArray array];
    NSMutableArray *obstacle = [NSMutableArray array];

    for (int i = 0; i < y; i++)
    {
        NSMutableArray *row = [NSMutableArray array];

        for (int j = 0; j < x; j++)
        {
            ASnode *node = [[ASnode alloc] init];
            CGPoint point = CGPointMake(i, j);
            node = [ASnode node];
            [node setPoint:point];
            [row addObject:node];
            _maxPoint = node;
        }

        [rows addObject:row];
    }
    _grid = rows;
    _obstacles = obstacle;
}

- (void)print
{

    CGPoint point = [_startPoint point];

    point.x;

    int s_x = (int) _startPoint.point.x;
    int s_y = (int) _startPoint.point.y;
    int f_x = (int) _finishPoint.point.x;
    int f_y = (int) _finishPoint.point.y;


    for (int i = 0; i < _grid.count; i++)
    {
        NSString *string = @"";
        NSString *symbol = @"";

        NSMutableArray *arrayRows = [_grid objectAtIndex:i];

        for (int j = 0; j < arrayRows.count; j++)
        {

            if ((s_x == i && s_y == j) || (f_x == i && f_y == j))
            {
                symbol = @"o ";
            }
            else
            {
                symbol = @"x ";
            }

            for (int k = 0; k < _obstacles.count; k++)
            {
                ASnode *obs = [_obstacles objectAtIndex:k];

                if ((i == obs.point.x) && (j == obs.point.y))
                {
                    symbol = @"| ";
                }

            }

            string = [string stringByAppendingString:symbol];

        }

        NSLog(@"%@", string);
    }

}

- (void)setObstacle:(ASnode *)node
{

    BOOL condition = TRUE;
    NSAssert(_grid != nil, @"Grid not found");

    if (_obstacles == nil)
    {
        _obstacles = [[NSMutableArray alloc] init];
    }

    if (node.point.x > _maxPoint.point.x || node.point.y > _maxPoint.point.y)
    {
        NSLog(@"Obstacle %f , %f is out of range : %f , %f ", node.point.x, node.point.y, _maxPoint.point.x, _maxPoint.point.y);
        condition = FALSE;
    }

    if (node.point.x == _startPoint.point.x && node.point.y == _startPoint.point.y)
    {
        NSLog(@"Obstacle and StartPoint at the same place");
        condition = FALSE;

    }

    if (node.point.x == _finishPoint.point.x && node.point.y == _finishPoint.point.y)
    {
        NSLog(@"Obstacle and FinishPoint at the same place");
        condition = FALSE;

    }

    for (int i = 0; i < _obstacles.count; i++)
    {
        ASnode *existedObstacle = [_obstacles objectAtIndex:i];
        if ((node.point.x == existedObstacle.point.x) && (node.point.y == existedObstacle.point.y))
        {
            NSLog(@"Obstacle %d , %d is already exist", node.point.x, node.point.y);
            condition = FALSE;
        }

    }

    if (condition)
    {
        [_obstacles addObject:node];
    }

}


- (ASnode *)findPath:(ASnode *)nodeA :(ASnode *)nodeB
{

    ASnode *result = nil;

    _startPoint = nodeA;
    _finishPoint = nodeB;

    return result;
}

@end