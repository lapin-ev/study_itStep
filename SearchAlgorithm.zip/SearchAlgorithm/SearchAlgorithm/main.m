//
//  main.m
//  SearchAlgorithm
//
//  Created by Jack Lapin on 12.02.15.
//  Copyright (c) 2015 JackLapin. All rights reserved.
//

#import "AStar.h"

int main(int argc, const char *argv[])
{
    @autoreleasepool
    {
        AStar *myWay = [[AStar alloc] init];
        [myWay createGrid:11 :9];


        ASnode *start = [ASnode node];
        ASnode *finish = [ASnode node];

        CGPoint point;

        point = CGPointMake(1, 0);

        [start setPoint:point];
        [finish setPoint:CGPointMake(7, 9)];


        [myWay findPath:start :finish];
        ASnode *obstacle = [ASnode node];

        [obstacle setPoint:CGPointMake(4, 4)];
        [myWay setObstacle:obstacle];

        [obstacle setPoint:CGPointMake(2, 3)];
        [myWay setObstacle:obstacle];

        [myWay print];

    }

    return 0;
}